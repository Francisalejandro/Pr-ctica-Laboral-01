import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UbicacionesQuery } from '../state/ubicaciones.query';
import { UbicacionesService } from '../state/ubicaciones.service';
import { Ubicacion } from '../state/ubicacion.model';
import { Observable, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-listado',
  imports: [CommonModule, FormsModule],
  templateUrl: './listado.component.html',
  styleUrls: ['./listado.component.css']
})
export class ListadoComponent implements OnInit, OnDestroy {

  ubicaciones$: Observable<Ubicacion[]>;
  loading$: Observable<boolean>;
  filtro: string = '';
  ubicacionSeleccionada: Ubicacion | null = null;
  seleccionadosIds = new Set<string | number>();
  private destroy$ = new Subject<void>();

  @Output() ubicacionSeleccionadaChange = new EventEmitter<Ubicacion>();
  @Output() rutaSeleccionada = new EventEmitter<Ubicacion[]>();

  constructor(
    private ubicacionesQuery: UbicacionesQuery,
    private ubicacionesService: UbicacionesService
  ) {
    this.ubicaciones$ = this.ubicacionesQuery.ubicacionesFiltradas$;
    this.loading$ = this.ubicacionesQuery.loading$;
  }

  ngOnInit() {
    this.ubicacionesQuery.filter$
      .pipe(takeUntil(this.destroy$))
      .subscribe((filtro: string | null) => {
        this.filtro = filtro || '';
      });
  }

  toggleSeleccion(ubicacion: Ubicacion) {
    if (this.seleccionadosIds.has(ubicacion.id)) {
      this.seleccionadosIds.delete(ubicacion.id);
    } else {
      this.seleccionadosIds.add(ubicacion.id);
    }
  }

  estaSeleccionado(ubicacion: Ubicacion): boolean {
    return this.seleccionadosIds.has(ubicacion.id);
  }

  emitirSeleccionados() {
    let seleccionados: Ubicacion[] = [];

    this.ubicaciones$.subscribe(lista => {
      seleccionados = lista.filter(u => this.seleccionadosIds.has(u.id));
    }).unsubscribe();

    this.rutaSeleccionada.emit(seleccionados);
  }

  aplicarFiltro(nuevoFiltro: string) {
    this.ubicacionesService.setFilter(nuevoFiltro);
  }

  seleccionarUbicacion(ubicacion: Ubicacion) {
    this.ubicacionSeleccionada = ubicacion;
    this.ubicacionSeleccionadaChange.emit(ubicacion);
  }

  capitalizarPrimeraLetra(texto?: string): string {
    if (!texto) return '';
    return texto.charAt(0).toUpperCase() + texto.slice(1).toLowerCase();
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
